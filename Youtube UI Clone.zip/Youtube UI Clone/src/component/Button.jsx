import React from "react";

const Button = () => {
  const btnList = [
    "All",
    "Music",
    "Sports",
    "Gaming",
    "News",
    "Movies",
    "Fashion",
    "Live",
    "Learning",
    "Spotlight",
    "360° Video",
  ];
  return (
    <div>
      {btnList.map((btn, index) => {
        return (
           <button key={index} className="rounded-lg px-5 py-2 m-2 bg-gray-200">{btn}</button>
        );
      })}
    </div>
  );
};

export default Button;
