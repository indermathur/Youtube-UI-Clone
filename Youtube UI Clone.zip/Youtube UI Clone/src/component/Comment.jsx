import React from 'react'
import user from '../assets/User.png'

const Comment = ({data}) => {
 const {authorName , commentText , authorPic} =  data;
  return (
    <div className='flex shadow-lg bg-gray-100 p-2 rounded-lg m-2'>
      <div>
        <img className='h-8 w-8' src={user} alt='user'/>
      </div>
      <div>
        <p className='font-bold'>{authorName}</p>
        <p>{ commentText}</p>
      </div>
    </div>
  )
}

export default Comment