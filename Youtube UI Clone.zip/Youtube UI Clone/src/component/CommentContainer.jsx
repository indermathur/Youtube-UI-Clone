import React, { useEffect } from "react";
import Comment from "./Comment";


const CommentContainer = () => {
  const commentsData = [
  {
    authorName: "Rohit Sharma",
    commentText: "This video was really helpful! Thanks for sharing 🙌",
    authorPic: "https://yt3.ggpht.com/ytc/AIf8zZT1rohitsharma-profile=s48-c-k-c0x00ffffff-no-rj"
  },
  {
    authorName: "Sneha Verma",
    commentText: "Great explanation, please make more videos like this ❤️",
    authorPic: "https://yt3.ggpht.com/ytc/AIf8zZT1sneha-profile=s48-c-k-c0x00ffffff-no-rj"
  },
  {
    authorName: "Aman Singh",
    commentText: "Can you please upload a tutorial on React API integration?",
    authorPic: "https://yt3.ggpht.com/ytc/AIf8zZT1aman-profile=s48-c-k-c0x00ffffff-no-rj"
  },
  {
    authorName: "Priya Patel",
    commentText: "Very well explained! Subscribed right away 👍",
    authorPic: "https://yt3.ggpht.com/ytc/AIf8zZT1priya-profile=s48-c-k-c0x00ffffff-no-rj"
  },
  {
    authorName: "Vikram Chauhan",
    commentText: "Bhai code part samajh aaya, UI part thoda fast tha 😅",
    authorPic: "https://yt3.ggpht.com/ytc/AIf8zZT1vikram-profile=s48-c-k-c0x00ffffff-no-rj"
  }
];



  return (
    <div className="m-5 p-2">
      <h1 className="text-2xl font-bold">Comments:</h1>
      {commentsData.map((comment, index) => {
        return (
          <div key={index}>
            <div>
              <Comment key={index} data={comment} />
            </div>
            <div className="pl-5 border-l-1 ml-5">
              <Comment key={index} data={comment} />
              
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default CommentContainer;
