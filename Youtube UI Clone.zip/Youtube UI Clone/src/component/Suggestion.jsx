import React, { useEffect, useState } from 'react'
import VideoCard from './VideoCard'
import { YOUTUBE_SUGGESTION_API } from '../utils/constant';
import { Link } from 'react-router-dom';
const Suggestion = () => {
    const [suggestions, setSuggestions]= useState([]);

    useEffect(()=>{
        getSuggestions();
    },[])

    const getSuggestions = async()=>{
        const data = await fetch(YOUTUBE_SUGGESTION_API);
        const json = await data.json();
        setSuggestions(json)
    }

  return (
    <div>
       {
         suggestions?.items?.map((video,index)=>{
            return <Link key={video.id} to={'/watch?v='+video.id}><VideoCard key={index} info={video} /> </Link>
       }
         )
        }
    </div>
  )
}

export default Suggestion