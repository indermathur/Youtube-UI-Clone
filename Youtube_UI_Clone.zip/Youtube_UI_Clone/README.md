Machine Coding 

Follow these point before 

1) Sabse pahle requirement clarification karo ki banana kya hai 
Usamein Feature kya developed karni hai

2) Tech Stack Confirm karo ki kya use karna hai 
Jaise State Mangement k liye kya - Redux vs Context API
Style k liye Kya - Vanilla CSS vs Tailwind
Routing k liye kya - react-router-dom
Testing k liye kya - jest for react testing

3) Planning - jaise mein youtube banaunga to usamein header hooga , header k andar hamburger icon hooga , jispe click krke side panel close or open hooga jismein home short subscription  etc hoga , header k andar logo hooga , search bar hooga , user icon hooga

header k baad main container hooga usmein top par buttton honge or niche vedio hogi , jispe click karke vedio open hoogi /watch page par khulegi / watch par same header hooga vedio play hoogi side mein vedio card hooge or niche comment section hooga




