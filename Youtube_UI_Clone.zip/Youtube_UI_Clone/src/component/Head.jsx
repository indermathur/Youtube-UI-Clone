import React, { useEffect, useState } from "react";
import Hamburger from "../assets/Hamburger.png";
import Youtube from "../assets/Youtube.png";
import User from "../assets/User.png";
import Search from "../assets/Search.png";
import { useDispatch } from "react-redux";
import { toggleMenu } from "../utils/appSlice";
import { YOUTUBE_SEARCH_API } from "../utils/constant";
import { Link } from "react-router-dom";

const Head = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    // console.log(searchQuery);
    const timer = setTimeout(() => getSearchSuggestions(), 200);
    return () => {
      clearTimeout(timer);
    };
  }, [searchQuery]);

  const getSearchSuggestions = async () => {
    const proxy = "https://cors-anywhere.herokuapp.com/";
    const data = await fetch(YOUTUBE_SEARCH_API + searchQuery);
    const json = await data.json();
    setSuggestions(json[1]);
  };

  const dispatch = useDispatch();
  const toggleMenuHandler = () => {
    dispatch(toggleMenu());
    // console.log("click huuya");
  };
  return (
    <div className="flex justify-between sticky top-0 z-50 bg-white p-5 m-2 shadow-lg ">
      <div className="flex mx-2">
        <img
          onClick={() => toggleMenuHandler()}
          alt="menu"
          src={Hamburger}
          className="h-8 cursor-pointer"
        />

        <img alt="youtube" src={Youtube} className="h-8" />
      </div>
      <div className="flex align-baseline">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
          }}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setShowSuggestions(false)}
          className="border w-150 border-gray-400 rounded-l-3xl  p-2 active:outline-blue-200 px-10"
        />
        {/* {console.log(showSuggestions) */}

        <button className=" border rounded-r-2xl w-15  border-gray-400 bg-gray-100">
          <img className="h-5 w-8 m-auto" src={Search} alt="search" />
        </button>
        {showSuggestions ? (
          <div className="fixed bg-white py-2 mt-12 px-5 w-[38rem] shadow-lg rounded-lg">
            <ul>
              {suggestions.map((s) => (
                <li key={s} className="py-2 shadow-sm hover:bg-gray-100">
                  🔍︎{s}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>

      <div>
        <img src={User} alt="User" className="h-10" />
      </div>
    </div>
  );
};

export default Head;
