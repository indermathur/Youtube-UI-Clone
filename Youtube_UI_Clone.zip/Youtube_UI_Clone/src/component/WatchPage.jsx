import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { closeMenu } from "../utils/appSlice";
import { useSearchParams } from "react-router-dom";
import CommentContainer from "./CommentContainer";
import Suggestion from "./Suggestion";

const WatchPage = () => {
  const [searchParam, setSearchParam] = useSearchParams();
  // console.log(searchParam.get("v"));

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(closeMenu());
  }, []);

  return (
    <div className="flex">
      <div>
        <div className="px-5">
          <iframe
            width="950"
            height="450"
            src={"https://www.youtube.com/embed/" + searchParam.get("v")}
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerpolicy="strict-origin-when-cross-origin"
          />
        </div>
        <div>
          <CommentContainer />
        </div>
      </div>
      <div className="ml-3 ">
        <Suggestion/>
      </div>
    </div>
  );
};

export default WatchPage;
